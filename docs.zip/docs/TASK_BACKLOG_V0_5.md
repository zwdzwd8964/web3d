# v0.5 任务卡清单

**用法**：agent 一次领一张，做完跑自测命令，绿了改 `[x]` 并回填耗时，再领下一张。
**上位文档**：[MVP_V0_5_进化规划.md](MVP_V0_5_进化规划.md) · [CLAUDE.md](../CLAUDE.md)（每张卡的 DoD 在那里）
**v0 台账**：[TASK_BACKLOG.md](TASK_BACKLOG.md)（历史存档，只读）

每张卡的字段：
- **依赖**：必须先完成的卡（`v0` 表示依赖已完成的 v0 交付物）
- **实际**：agent 实时耗时（小时）。与人日预估不是同一量纲，只用来看**卡与卡之间**的相对
  大小和"是否显著超出预期"（CLAUDE.md 停工条款第 6 条）
- **独占**：这张卡会创建/修改的文件。**多 agent 并行时，独占文件不重叠的卡才能同时开工**；
  同分支串行卡允许独占重叠（波次表里排同一列即可）
- **验收**：怎么算做完
- **自测**：跑什么命令

标 ★ 的是**接口/地基先行卡**——完成后同时解锁多条并行分支。

**本版新纪律（对每张卡生效）**：
1. 新增的每条测试附一次**变异检验**（把被测行为故意改坏 → 测试必须转红），在提交信息里记录；
2. 涉及 ECA 动作的卡，`executor.ts` / `engine.ts` / 规则编辑器组件的 diff 必须为空；
3. 涉及渲染能力的卡，`packages/player/src` 的 diff 必须为空（能力长在 core，播放器自动获得）。

---

## 并行波次

单 agent 顺序模式可忽略本节，直接从 T-115 按编号做。

| 波次 | 可同时开工 | 前置 |
|---|---|---|
| W0 | T-115, T-116, T-117, ★T-120 | —（四张卡独占互不重叠） |
| W1 | T-121, T-122, ★T-130, T-145 | T-120（T-145 仅依赖 T-120） |
| W2 | T-131 ｜ T-140 ｜ T-150 | W1 对应 ★ 卡 |
| W3 | T-132 → T-133 → T-134（同独占串行）｜ T-141 → T-142 ｜ T-151 → T-153 ｜ T-160 | W2 |
| W4 | T-135 → T-136 ｜ T-143, T-144 ｜ T-152 → T-154 ｜ T-161, T-162, T-163 | W3 |
| W5 | T-155 | T-141, T-145, T-150, T-133 |
| W6 | T-170 → T-171, T-172, T-173, T-174 | 全部功能卡 |
| W7 | T-175, T-176 | W6 |

---

## E11 · v0 清债（先还债，再进化）

### [x] T-115 · E2E 与缩略图假绿断言修复
- **依赖** v0 · **预估** 0.8d · **实际** 0.7h
- **独占** `e2e/tests/golden-path-full.spec.ts`, `packages/core/test/assets/thumbnail.test.ts`
  （+ `packages/editor/src/viewport/runtime-registry.ts`：新增 DEV-only 只读钩子
  `__w3DevMaterialOf`，"渲染侧生效"没有它就只能靠像素猜——理由见文件内注释）
- **做** 修 [IMPL_NOTES](IMPL_NOTES.md) §4 登记的四条：①第 6 步真实修改 roughness 并断言文档与渲染侧生效（当前定位到的"roughness 控件"其实是材质下拉框）；②第 8 步用数量前后对比断言"新建补间"生效（弃用 `.first()`）；③第 9 步断言**本次新建**的热点而非样例遗留热点；④缩略图取景断言读取 `view.target` 且样本包含非零 y/z 分量。每条修完做一次变异检验。
- **验收** 四处变异检验转红记录在提交信息；全套 E2E 仍绿
- **自测** `pnpm test:e2e && pnpm -F @w3/core test thumbnail`

### [x] T-116 · benchmark 假绿与包兼容提示清偿
- **依赖** v0 · **预估** 0.8d · **实际** 0.6h
- **独占** `packages/player/test/bench-metrics.test.ts`, `packages/player/src/bench/main.ts`, `packages/player/src/bench/metrics.ts`, `packages/storage/src/package.ts`, `packages/storage/test/package.test.ts`
  （+ `packages/player/src/compat.ts` 改为委派给 storage 的新版本闸门，避免同一句中文提示
  在两个包里各写一份；+ [ADR-0016](adr/0016-逐级加载压力测试的含义.md)：③ 的「逐级加载压力测试」
  在任何规范里都没有定义，按铁律 12 先写 ADR 再实现）
- **做** ①p95 断言改为构造已知帧分布并断言精确分位值（当前 `toBeGreaterThanOrEqual(16.7)` 把 p95 写成"最慢帧"也全绿）；②`BENCH_LIMITS.textures` 真正参与 `gradeScene` 评级，或从断言中移除并注明理由；③补 T-110 卡片明列但缺失的「逐级加载压力测试」；④`unpackScene` 先 `assertCompatible` 再解析，让 from-the-future 包的中文提示不再是死代码，附一条对应测试。
- **验收** 变异检验（p95 实现改回"最慢帧"→ 测试红）；from-the-future 包报中文明确错误
- **自测** `pnpm -F @w3/player test && pnpm -F @w3/storage test package`

### [x] T-117 · CI 工作流落地
- **依赖** v0 · **预估** 0.5d · **实际** 0.8h（含三轮推送验证）
- **独占** `.github/workflows/ci.yml`
- **做** GitHub Actions：constitution → typecheck → lint → 全部单测 → build → size-limit；Playwright E2E 单列 job（可 nightly）。pnpm 缓存。补上 IMPL_NOTES §4 点名的「T-105 超标 CI fail 没有落点」。
- **验收** 分支上推送一次全绿；临时把 size 预算调小验证 CI 会红（验证后还原）
- **自测** 推送后观察 CI 结果
- **实际情况**：步骤顺序较卡片有调整——`build` 提到最前，两个理由都只在干净机器上才
  显形：① 各包经 `types: ./dist/*.d.ts` 认识兄弟包，没构建时 `pnpm -r typecheck` 一行
  都查不到就挂（**CI 首跑就是被这条抓红的**，见 [IMPL_NOTES](IMPL_NOTES.md) §4）；
  ② `check:constitution --require-build` 未构建即 fail。另加 `pnpm test:parity`
  （属于 `pnpm verify`，卡片未列但漏了就是 CI 里没有 C3 守卫）。
  体积闸门「会红」已本地验证：预算临时改 100 KB → `pnpm size` 打印 FAIL 并 exit 1（已还原）。
  **推送验证已完成**：前两轮红（各抓到一条本机看不见的真问题），第三轮两个 job 全绿
  （run 30660510375：verify 44s · E2E 2m1s）。

---

## E12 · schema v2

### [x] T-120 · schema v2 三件套 ★
- **依赖** 无（与 T-115 ~ T-117 可并行开工） · **预估** 1.5d · **实际** 1.6h
- **独占** `packages/schema/src/{node,light,primitive,material,document,deferred,media,migrate,primitives}.ts`, `packages/schema/test/fixtures/v2/golden-path-2.json`, `packages/schema/test/migrate.test.ts`, `docs/SCHEMA_SPEC.md`
  （版本 bump 的必然波及，逐一登记：`schema/src/{factory,index}.ts` 与
  `schema/test/{fixtures,validate,remap,index-builder}.test.ts` —— `Node` 类型多两个必填字段，
  凡是手写节点字面量的地方都要补；`core/src/assets/instantiate.ts` 同理；
  `core/test/{assets/pipeline,runtime/apply-patch,runtime/scene-graph}.test.ts`、
  `storage/test/package.test.ts` 里的 `schemaVersion: 1` 字面量改为读 `CURRENT_VERSION`；
  **`editor/src/main.tsx` 是唯一一处真缺陷**，见下）
- **做** 按进化规划 **§4.1 逐字**落地：节点承载体 `primitive` / `light`（新文件 `primitive.ts` / `light.ts`）、`meta.environment` 与 `background` 增 `'hdri'`、材质 physical 参数与 `uv` 块、`MediaSchema` 从 `deferred.ts` 出列进 `media.ts`（+`name` / `durationS`）、`Vec2`。`CURRENT_VERSION = 2` + 迁移 `1→2`（纯函数补默认值，**不注入灯节点**，D14）+ fixture `v2/golden-path-2.json`（黄金路径 II 终态文档）。v1 fixture 只增不改不删。**同步回写 SCHEMA_SPEC.md** 对应章节（§1/§4/§6/§7/§10，标注 v2 增量）。
- **验收** 三件套齐；v1 与 v2 fixture 均 `migrate → validate → checkIntegrity` 零 error；文档 JSON 往返 `toEqual`；无手写 interface、无裸 `z.string()` 当枚举
- **自测** `pnpm -F @w3/schema test`
- **⚠ 完成后停下来汇报，等人工确认再继续。** 字段形状错了，后面六个里程碑全错，且单测发现不了。
- **本卡抓到的一条真缺陷**：`editor/src/main.tsx` 的恢复路径用 `validate` 而不是 `migrate`。
  v1 是唯一版本时看不出来，v2 一上线就变成"升级后所有工程消失"——文档还在盘上，用户看到的
  是样例场景，与数据丢失无法区分（直接违 C4）。已改为 `migrate` 并记录升级日志；
  用一次性 Playwright 脚本播种 v1 工程实测通过（把 `migrate` 改回旧行为 → 转红），
  常设回归测试归 T-172。

### [x] T-121 · 完整性检查增量 I11–I15
- **依赖** T-120 · **预估** 0.5d · **实际** 0.5h
- **独占** `packages/schema/src/integrity.ts`, `packages/schema/test/integrity.test.ts`
  （+ `index-builder.ts` 的 `RefTarget` 增可选 `expectType`：I14 第三句「playMedia 只能引用
  audio」是**动作知识**，硬编码动作名会把 ECA 语义塞进唯一不许认识 ECA 的包。改为解析器
  报约束、schema 只负责执行，与 id 解析同一套分工）
- **做** 进化规划 §4.2 的五项：I11 承载体互斥、I12 环境引用与背景依赖、I13 贴图槽位资产类型、I14 媒体类型匹配（含 `playMedia` 目标必须为 audio）、I15 physical 参数错配（warn）。
- **验收** 每项至少一条正例 + 一条反例单测
- **自测** `pnpm -F @w3/schema test integrity`
- **实际情况**：I13 比 v0 的同类检查更严——原来 I3 里那段允许 `image`，v0.5 明确把
  `texture`（材质采样）与 `image`（媒体展示）分开，两条规则并存会让人说不清哪条才算数，
  所以把类型判断整体挪进 I13。8 次变异检验逐条转红。

### [x] T-122 · 工厂、选择器与索引增量
- **依赖** T-120 · **预估** 0.5d · **实际** 0.5h
- **独占** `packages/schema/src/factory.ts`, `packages/schema/src/selectors.ts`, `packages/schema/src/index-builder.ts`, 对应 `test/*.test.ts`
- **做** `createPrimitiveNode` / `createLightNode` / `createMediaRecord`；`ensureDefaultMaterial(doc)`（无则创建名为「默认材质」的共享记录并返回 id，D15）；`DocIndex` 增 `mediaById`；`refsTo` 覆盖 `hotspot.content.mediaId` 与 `media.assetId`；selectors 增灯/原始体节点查询。
- **验收** 工厂产物直接过 `validate`；`refsTo` 能回答"删除 med_x 会影响哪些热点/规则"
- **自测** `pnpm -F @w3/schema test`
- **实际情况**：`refsTo` 对 `hotspot.content.mediaId` 与 `media.assetId` 在 v0 就已覆盖，
  本卡补的是**没人点名但会静默出事的第三条**——`meta.environment.hdriAssetId`：它不挂在任何
  节点上，删掉那张 .hdr 时删除确认框会说"无人引用"，然后场景照明整个消失。
  另加两个选择器给 core 用：`getCarrier`（三种承载体归一成一个可 switch 的值，T-130 的
  分发点）与 `needsDefaultLightRig`（D14 的判据放 schema，编辑器与运行时不可能对它有分歧）。
  8 次变异检验逐条转红。

---

## E13 · 光照与环境（`@w3/core`）

### [x] T-130 · 场景图承载体分发 ★
- **依赖** T-120 · **预估** 0.8d · **实际** 1.2h
- **独占** `packages/core/src/runtime/scene-graph.ts`, `packages/core/src/runtime/apply-patch.ts`, `packages/core/src/runtime/carrier-types.ts`, `packages/core/test/runtime/scene-graph.test.ts`, `packages/core/test/runtime/apply-patch.test.ts`
- **做** 场景图识别三种承载体（assetRef / primitive / light），primitive 与 light 的 Object3D 构建委托给 `PrimitiveFactory` / `LightFactory` 接口（本卡定义接口 + 占位实现，真实实现在 T-140 / T-131）。applyPatch 增路径分发：`/nodes/i/primitive/**`、`/nodes/i/light/**`、`/meta/environment/**`、`/meta/background/**`、`/media/**`——**每类路径都不落全量重建**。
- **验收** 新路径逐类有单测；`fullRebuildCount` 在全部新路径上为 0
- **自测** `pnpm -F @w3/core test scene-graph apply-patch`
- **实际情况**：顺手清掉了 IMPL_NOTES §4 登记的那条 major——黄金路径 `fullRebuildCount`
  实测为 1。根因不在新路径上，而在**索引位移**：immer 把 `nodes.splice(2,1)` 描述成
  `replace /nodes/2` + `remove /nodes/3`，按字面读会删掉一个还活着的节点、再重复添加失败。
  现在整条黄金路径实测 0，并在 E2E 末尾（第 12 步之后）补了断言——原来两处断言都在
  那次回落之前，这才是它活了一整个版本的原因。
  另修 `resyncNode` 把非 Mesh 节点的 `applyToNode === false` 当成"未识别"：**文档里
  只要有一盏灯，任何 `/nodes` 整体替换都会回落全量重建**（灯没有 mesh），D1 的报警器
  会从 M9 开始持续鸣叫。还顺带修了 `disposeSubtree` 无差别 dispose 几何——资产实例的
  几何是共享的，删一个节点会让同一零件的其他实例白掉到下次上传。13 处变异检验全红。

### [x] T-131 · LightFactory：五种灯
- **依赖** T-130 · **预估** 0.8d · **实际** 0.6h
- **独占** `packages/core/src/runtime/light-factory.ts`, `packages/core/test/runtime/light-factory.test.ts`
- **做** ambient / hemisphere / directional / point / spot 的构建与增量更新；方向性灯沿节点局部 -Z（D13，target 由世界矩阵每帧推出，不进文档）；`angleDeg` → 弧度；`quality` → mapSize 512/1024/2048；颜色/强度/角度等参数 patch **就地更新**不重建，`kind` 变更走重建 + dispose。
- **验收** 每种灯一条构建断言 + 一条增量更新断言；-Z 朝向有数学断言（旋转节点 → 光照方向随动）
- **自测** `pnpm -F @w3/core test light-factory`
- **实际情况**：D13 的实现不需要每帧 tick——把 target 挂成灯的**子对象**放在局部 -Z，
  three 自己每帧从灯的世界矩阵推出朝向。10 处变异检验全红，其中两条值得记：
  target 不挂成子对象（回到 three 默认的游离 target）→ 5 条红；换阴影质量不 dispose
  旧 map → 红（three 只在首次按 mapSize 分配，不 dispose 的话"高"档永远还在 512 渲染，
  控件看起来什么也没干）。

### [x] T-132 · 阴影管线
- **依赖** T-131 · **预估** 0.5d · **实际** 0.5h
- **独占** `packages/core/src/runtime/scene-runtime.ts`（阴影段）, `packages/core/test/runtime/scene-runtime.test.ts`
- **做** 存在任一 `shadow.enabled` 灯 → 开 `renderer.shadowMap`（PCFSoft），全关 → 关闭；阴影管线开启时 mesh 缺省 `castShadow = receiveShadow = true`，`node.overrides.castShadow / receiveShadow`（v0 字段，此前空转）接通生效；`bias` 应用。
- **验收** 无 GL 断言对象标志位与 shadowMap 开关联动；overrides 关掉单个节点的投影有效
- **自测** `pnpm -F @w3/core test scene-runtime`
- **本卡抓到的一条 blocker**：`SceneRuntime` 从来没把真的 `lightFactory` 装进 `SceneGraph`，
  所有 `node.light` 都落到占位工厂的空 Group —— 层级树里有灯、gizmo 能拖、patch 能到，
  场景照样是黑的。T-131 与 T-130 各自全绿，因为两边都在对着对方的替身测。已装上并补一条
  直接断言"灯节点必须变成真的 three 灯"的测试。`bias` 由 T-131 的 LightFactory 应用，
  已有覆盖（light-factory.test.ts）

### [x] T-133 · 环境与背景（HDRI / IBL）
- **依赖** T-132 · **预估** 0.8d · **实际** 0.7h
- **独占** `packages/core/src/runtime/environment.ts`, `packages/core/src/runtime/scene-runtime.ts`（环境段）, `packages/core/test/runtime/environment.test.ts`
- **做** `AssetResolver` 取 `.hdr` 字节 → `RGBELoader.parse` → PMREM → `scene.environment`（`intensity` 走 `scene.environmentIntensity`）；`background.type === 'hdri'` 时同图作背景；`exposure` → `toneMappingExposure`；`hdriAssetId` 非空切 ACESFilmic、清空还原 v0 现状（进化规划 §4.1.4）；卸载与切换时 dispose PMREM 与纹理。
- **验收** 设 → 清 → 再设无泄漏（`renderer.info` 纹理计数还原）；无 HDRI 文档的 toneMapping 与 v0 相同
- **自测** `pnpm -F @w3/core test environment`
- **实际情况**：三处需要记：①用 `HDRLoader` 而不是卡片写的 `RGBELoader`——同一个 RGBE
  解析器，后者在 three 0.185 里是**已废弃别名**，构造时会打印弃用警告；零新增依赖
  （登记进 IMPL_NOTES §3）。②PMREM 需要真 GL，所以把「equirect → 预过滤」抽成可注入的
  `compile`，其余（选哪张、何时重取、场景读什么、释放什么）全是文档逻辑，纯 Node 可测；
  `renderer.info` 计数要 GL，改为对自己分配的对象记账并在测试里说明。③`scene.background`
  的所有权整体收进 `EnvironmentController`——原来 `applyBackground` 会在任何 meta 变更时
  把 `background.color` 刷到 HDRI 背景上，症状（改个项目名字，HDRI 背景变回灰）看起来
  和背景色八竿子打不着。

### [x] T-134 · 默认灯架条件退场 + 老文档观感回归
- **依赖** T-133 · **预估** 0.5d · **实际** 0.4h
- **独占** `packages/core/src/runtime/scene-runtime.ts`（installLighting 段）, `packages/core/test/runtime/default-rig.test.ts`
- **做** D14：文档无灯节点且 `environment.hdriAssetId` 为空 → 挂 v0 默认三灯 rig（不进文档、不可拾取）；出现任一灯或环境 → rig 整体退场；删光复原。加载 v1 fixture 断言 rig 存在且**三灯参数与 v0 逐项相等**（G0.5-6 的落点）。
- **验收** 增删最后一盏灯往返，rig 出场/退场正确；老文档观感回归绿
- **自测** `pnpm -F @w3/core test default-rig`
- **实际情况**：G0.5-6 那条测试里，v0 三灯的参数是**手抄的字面值**，不是从实现里读回来的。
  从实现读等于写 `rig.intensity === rig.intensity`，一条永远不会红的断言——而这正是一条
  晋级门槛该有的样子的反面。判据 `needsDefaultLightRig` 在 schema（T-122），编辑器与运行时
  不可能对"该不该挂默认灯"产生分歧。

### [x] T-135 · `setLight` 动作
- **依赖** T-131, T-134 · **预估** 0.5d · **实际** 0.7h
- **独占** `packages/core/src/eca/actions/light.ts`, `packages/core/src/eca/types.ts`, `packages/core/src/eca/headless.ts`, `packages/core/src/runtime/scene-runtime.ts`（ctx 实现段）, `packages/core/test/eca/actions.test.ts`, `packages/core/test/runtime-contract.ts`, `docs/ECA_SPEC.md`
- **做** 进化规划 §4.3：`RuntimeContext.setLight` 双实现 + 契约测试条目；动作五项齐全（schema / handler / ui / refs / describe，describe 中文）；目标节点非灯时 skip + error 日志（B9 同款语义）。**回写 ECA_SPEC.md** 动作表与 RuntimeContext 章节。`executor.ts` / `engine.ts` / 规则编辑器 diff 为空。
- **验收** 覆盖率门槛 14/14；规则编辑器零改动可编辑该动作（既有 rule-editor 测试自动把关）
- **自测** `pnpm -F @w3/core test eca`
- **实际情况**：`executor.ts` 与 `packages/editor` 的 diff **确为空**；**`engine.ts` 不为空**
  ——它的 `withCurrentEvent` 是手写逐方法委托，每加一个 RuntimeContext 方法都得改它一行，
  与动作类型无关（C5 的实质没破）。这条纪律对进化规划 §4.3 强制的四个新方法字面上不可满足，
  T-163 还会再撞一次。已登记 IMPL_NOTES §4 并给出修法（Proxy 委托），**未擅自重构引擎**。
  另两处：颜色字段用 `type: 'string'` 而不是新增 `'color'` 字段类型（§4.4 是封闭六种，
  加一种等于同时改规范和改规则编辑器）；契约测试的灯光读取器由 harness 提供而不是往
  `RuntimeContext` 上加 `getLight`——为测试方便加宽冻结清单，冻结就不再有意义。
  三次变异检验，其中**第二次一开始没抓住**：只传 intensity 时，把「目标必须是灯」的守卫
  整个删掉，测试照样全绿（往错的 Object3D 上写个数字在 JS 里是静默成功的）。断言改为同时
  传颜色后才转红——已写进契约测试的注释。

### [x] T-136 · 灯光 helper 与拾取（编辑态）
- **依赖** T-131 · **预估** 0.5d · **实际** 0.6h
- **独占** `packages/core/src/runtime/light-helpers.ts`, `packages/core/src/runtime/picker.ts`, `packages/core/test/runtime/light-helpers.test.ts`
- **做** `mode: 'edit'` 时为灯节点挂对应 helper + 不可见代理球供射线拾取（灯没有 mesh，点不中就没法选中调参）；helper 不进文档；`mode: 'play'` 下零 helper 对象；locked 灯不可拾取（沿 v0 语义）。
- **验收** 编辑模式点选灯节点命中正确 nodeId；play 模式 helper 计数为 0
- **自测** `pnpm -F @w3/core test light-helpers`
- **实际情况**：helper 图层挂在 `scene` 上、**不挂在 `graph.root` 下**，代价是 picker 要多
  认一个根（`setAuxRoot`，本卡独占里的 picker.ts 就是为这个留的）。理由：全览是
  `Box3.setFromObject(graph.root)`，而灯今天对这个盒子毫无贡献（没有几何体）——把点击代理
  放进文档图，会让"加一盏灯"改变整个场景的取景。代理用 `material.visible = false` 而不是
  `object.visible = false`：两者都不画，但射线检测测的是**对象**，对象级隐藏会让灯变成
  点不中的——那正是这层要解决的问题本身。
  写测试时抓到一个真 bug：`update()` 之后没刷新世界矩阵，而 picker 直接读 `matrixWorld`。
  生产里靠每帧 render 顺手刷新掩盖了，但用户在刚打开的工程上点第一下时 picker 先跑——
  那一刻所有代理还在原点，点哪盏灯都命中同一个位置。已在层内 `updateMatrixWorld(true)`。

---

> **M9「亮起来」收尾对抗式审查已完成**（T-130 ~ T-136）：三个视角，一条 major 当场修掉
> （退出预览后灯光 helper 指向已丢弃的灯对象），两条 minor 如实登记，两条怀疑被自己证伪。
> 详见 [IMPL_NOTES](IMPL_NOTES.md) §4。

## E14 · 对象库与放置体验

### [x] T-137 · 灯光创建与灯光面板（M12 / T-170 审查补票）
- **依赖** T-131, T-136 · **预估** 0.8d · **实际** 0.8h
- **独占** `packages/editor/src/panels/LightPanel.tsx`（增）, `packages/editor/src/lib/light-edit.ts`（增）, `packages/editor/src/panels/LibraryPanel.tsx`（对象页签的"灯光"分区）, 对应测试
- **为什么存在** T-170 写到第 ⑥ 步「新建聚光灯节点」时发现：**编辑器里没有任何创建灯光的入口**。
  T-130 ~ T-136 在 core 里把灯光栈整个建完了——五种灯的工厂、阴影管线、IBL 环境、默认灯架条件
  退场、`setLight` 动作、helper 与射线拾取，全部有测试且全绿——而**没有一张卡负责"用户怎么新建
  一盏灯"**。台账从 T-136 直接跳到 T-140（原始体）。`createLightNode` 在 `@w3/schema` 里躺着，
  全仓零调用者。
  这不是某张卡漏做了，是**规划本身缺了一格**：灯光那条链上每一环都被指派了，唯独"入口"没有。
  与 M10 抓到的三条同形（卡面写了没接线），但更靠上游——这次是卡面本身就没写。
- **做**
  1. 资源库「对象」页签增"灯光"分区：五种灯（环境光 / 平行光 / 点光 / 聚光 / 半球光），
     双击或拖放创建，走与原始体同一条放置流程（T-142 / T-146），一条 commit。
  2. `LightPanel`：选中灯节点时显示 kind / color / intensity，聚光灯多 angleDeg / penumbra，
     点光与聚光多 range / decay，阴影开关 + quality + bias。全部走 commit / preview（拖滑块
     一条撤销）。
  3. 层级树给灯节点一个可区分的图标——灯没有网格，在树里与空组看起来一样。
- **验收** 新建五种灯各能在视口里看出光照变化；聚光灯开阴影后展台上出现影子；
  拖 gizmo 旋转即改变照射方向（D13，无 target 对象）；删除最后一盏灯后默认灯架回来（D14 回归）
- **自测** `pnpm -F @w3/editor test light-edit`（18）
- **实际情况**：`light` 是**判别联合**，所以换类型必须**重建**而不是逐字段合并——聚光灯的
  `angleDeg` 留在点光源上是 `.strict()` 会拒的字段，文档**存得下、打不开**，这里最糟的一种坏法。
  只把两种类型都有的 intensity / color 带过去（而且 `color` 还要判断目标类型有没有这个字段，
  半球光就没有——变异 T2 就是从这里溜进去的）。
  新建的平行光与聚光灯**朝下倾斜 50°**：单位四元数指 -Z 是水平的，照不到地面上任何东西，
  看起来就是"这灯坏了"。方向本身仍然只由节点旋转决定（D13），面板里没有第二个瞄准控件。
  面板会说「当前用的是内置默认灯架，加入第一盏灯后它会自动退场」——否则用户新建的**第一盏灯
  会让场景变暗**（灯架走了、一盏弱灯顶上），而屏幕上没有任何东西解释这件事（D14）。

### [x] T-140 · PrimitiveFactory：七种原始体
- **依赖** T-130 · **预估** 0.5d · **实际** 0.6h
- **独占** `packages/core/src/runtime/primitive-factory.ts`, `packages/core/test/runtime/primitive-factory.test.ts`
  （+ `scene-runtime.ts` 一行接线，+ [ADR-0017](adr/0017-原始体的朝向与分段数.md)）
- **做** 七种语义尺寸 → BufferGeometry（分段数固化在 core，不进文档，进化规划 §4.1.2）；参数 patch → 几何重建 + 旧几何 dispose；bbox 正确（贴面放置依赖它）；`overrides.materialId` 缺失时兜底渲染中性灰 standard 并 warn（文档态由编辑器创建时显式挂默认材质，D15）。
- **验收** 每种一条尺寸断言（bbox 与语义尺寸一致）；参数更新后旧几何已 dispose（`renderer.info` 断言）
- **自测** `pnpm -F @w3/core test primitive-factory`
- **实际情况**：规范只冻结了语义尺寸，没写**朝向**与**分段数**，两者都是改不回来的决定，
  按铁律 12 先写 [ADR-0017](adr/0017-原始体的朝向与分段数.md)：七种体全部沿用 three 的默认
  朝向（plane 因此是竖着的，想要地面自己转 90°，且这个旋转落在文档的 `transform.r` 里——
  烘进几何等于给用户一份看不见也改不掉的隐藏状态），分段数写死在 core。
  旧几何 dispose 用 three 的 `dispose` 事件断言，不用 `renderer.info`——后者要真 GL 上下文，
  而这条断言的内容（"改一次尺寸不泄漏一个 buffer"）本身不需要 GPU。
  **接线断言单独写了一条**：T-132 刚因为"工厂建好了、分发建好了、没人接线"栽过一次，
  同形状的坑一个文件之隔，不靠推断。变异检验：去掉 `{ primitives: primitiveFactory }`
  → 3 条转红。

### [x] T-141 · 资源库面板（对象页签）
- **依赖** T-122, T-140, T-145 · **预估** 1d · **实际** 0.8h
- **独占** `packages/editor/src/panels/LibraryPanel.tsx`, `packages/editor/src/lib/library.ts`, `packages/editor/test/library.test.ts`
- **做** 资源库面板骨架（页签：对象 / 纹理 / 环境，后两个页签本卡占位、T-155 填充）；对象页签 = 7 种原始体 + manifest 内置模型；双击 = 放到视口中心地面，拖出 = 进入 T-142 放置流程；库模型首次引入走**既有导入管线**（hash 查重、体检、缩略图），二次引入命中缓存不重复存储。
- **验收** 断网下面板完整可用；库模型引入后出现在资产面板；创建原始体时 `ensureDefaultMaterial` 生效（材质面板非空）
- **自测** `pnpm -F @w3/editor test library` + `pnpm dev` 目视
- **实际情况**：面板里有两类完全不同的东西，分开是整个设计：**原始体不是内容**（七个 schema
  枚举值，创建它只写一个节点，没有字节、没有资产记录、没有存储），**库条目是文件**（由 manifest
  描述，只有用户真的用到时才成为项目资产，且走**既有导入管线**——D17 第三条纪律）。
  manifest 在运行时**再校验一遍**：构建期脚本守的是仓库，这一遍守的是部署时被改过的 manifest。
  缺 license / 路径是 URL / 路径越界的条目直接丢弃并**报数**——静默显示 8 项中的 5 项，
  与「本来就只有 5 项」在用户那里无法区分。测试拿**仓库里真实的 manifest** 当输入：只见过
  手写 fixture 的校验器，证明不了用户看到的那八项。两次变异检验：不再要求 license、
  原始体不挂默认材质。纹理 / 环境两个页签本卡只占位并**写明「T-155 接通」**——看起来坏掉的
  页签比会自我解释的页签更糟。另动 `App.tsx`（挂页签）与 `styles.css`（网格样式），独占外。

### [x] T-142 · 拖拽放置与落点规则
- **依赖** T-141 · **预估** 0.8d · **实际** 0.8h
- **独占** `packages/editor/src/viewport/place.ts`, `packages/editor/src/viewport/Viewport.tsx`（drop 接线）, `packages/editor/test/place.test.ts`
- **做** D18：拖到视口 → 射线命中场景表面 → 包围盒**底面**对齐命中点；未命中 → 地平面 y=0；拖拽中的幽灵预览走 `preview` 通道；松手 = **一条 commit**（新建节点 + 挂默认材质一体）。
- **验收** 一次放置在撤销栈里恰好一条，Ctrl+Z 整体消失；贴面与落地两分支均有测试
- **自测** `pnpm -F @w3/editor test place` + `pnpm dev` 目视
- **实际情况**：落点算的是**包围盒底面**，不是原点——导出器可以把原点放在任何地方（网格内部、
  某个角上、五米开外），"把原点放到命中点"对最需要放置的那类模型正好会插进桌面。包围盒由
  `primitiveBounds` **从真实几何量出来**，不是照参数再推一遍：两份"胶囊体多大"的公式必然漂移，
  而症状是物体轻微陷进地面，没人会往重复公式上想。
  **本卡在 core 加了两样**（独占外，必需）：`Picker.pickPlane`（编辑器不许 import three，射线是
  渲染概念）与 `primitiveBounds`。另外抓到并修了一个真 bug：**`Raycaster` 读 `matrixWorld` 而
  从不刷新它**，此前只有 `renderer.render` 会刷——于是"文档变更后、下一帧之前"的拾取（包括
  场景刚加载后的第一次点击）打的是物体**曾经**在的位置。是被放置测试逼出来的：y=0.1 的盒子被
  当成在原点。已在 `Picker` 内刷新，附回归测试；**第一版回归测试没抓住变异**（没更新过的
  matrixWorld 就是单位阵，也就是原点），改成"先刷新→再移开→必须打不中"才有判别力。
  C6 守卫还抓到我在源码里写的 `http://localhost/` 兜底常量会进 bundle——`base` 改为必填参数。

### [x] T-143 · 吸附（网格 / 角度）
- **依赖** T-142 · **预估** 0.5d · **实际** 0.5h
- **独占** `packages/core/src/runtime/gizmo.ts`（snap API）, `packages/editor/src/viewport/SnapToolbar.tsx`, `packages/editor/test/snap.test.ts`
- **做** core gizmo 增 `setSnap({ translate?: number; rotateDeg?: number })`；工具栏：网格 0.1 / 0.5 / 1 m 三档 + 角度 15° 开关；吸附同时作用于 gizmo 拖拽与 T-142 的放置落点；设置为**编辑器会话态**（不进文档、不进 localStorage，D18）。
- **验收** 开吸附拖动后文档坐标为格点值；关吸附行为与 v0 完全一致
- **自测** `pnpm -F @w3/editor test snap` + `pnpm dev` 目视
- **实际情况**：会话态放在 `viewport/snap.ts`（独占外新增一个文件）——不能只住在 SnapToolbar 里，
  因为**读它的另一个是 gizmo，而 gizmo 根本不是 React 组件**（ADR-0009）；两个所有者会长出
  「工具栏显示 0.5m 而拖拽是自由的」。吸附**只作用于 X/Z**：Y 是物体**停靠**的高度，来自射线
  命中的表面，把它也四舍五入会把刚放上桌面的盒子抬起来或压进地板——网格是平面图，不是立体点阵。
  `setSnap` 把 0 归一成 null：three 把 `translationSnap: 0` 读成"吸附到 0 的倍数"，手柄会直接
  不动——一个会冻住 gizmo 的关闭开关比没有开关更糟。角度在**边界**处转弧度（用户输入一律是度）。
  三次变异检验：向下取整、Y 也吸附、0 直接透传给 three。

### [x] T-144 · 复制 / 粘贴 / Ctrl+D
- **依赖** T-122 · **预估** 0.5d · **实际** 1.0h
- **独占** `packages/editor/src/store/clipboard.ts`, `packages/editor/src/shortcuts.ts`（增）, `packages/editor/test/clipboard.test.ts`
  （+ `packages/editor/src/App.tsx`：原先长在 App 里的 `useShortcuts` 搬进新模块，App 只剩一行 import）
- **记** 快捷键的判断逻辑抽成纯函数 `handleShortcut(event, deps)`，hook 只负责接线：编辑器单测跑在纯 Node（无 jsdom），
  留在 `useEffect` 里的规则只能被描述、无法被执行。「一次粘贴一条 commit」的断言用**补丁批次数**而不是 undo 步数——
  History 会把 500ms 内同名 commit 合并，逐节点提交在 undo 下看起来一模一样（变异 M7 第一次存活）。
  `taken.add(id)` 的变异（M4）同样存活过一次：顺序 id 工厂自带计数器，无论传什么都不会重复；补了一条会撞的工厂才照出来。
- **做** 复制节点**子树**：全部新 id、保持相对层级与 order 间隔、材质引用共享（不 clone 记录）、**不复制规则与热点**（灰区裁决）；粘贴位置 = 原位偏移 `[0.2, 0, 0.2]`；一次粘贴一条 commit；剪贴板为内存态（跨项目粘贴不支持）。
- **验收** 粘贴后 `checkIntegrity` 零 error；undo 一步整树消失；输入框聚焦时快捷键不误触发（沿 T-071 语义）
- **自测** `pnpm -F @w3/editor test clipboard`

### [x] T-146 · 库模型拖放、幽灵预览与双击落点（M10 审查补票）
- **依赖** T-141, T-142, T-143 · **预估** 0.8d · **实际** 2.4h
- **独占** `packages/core/src/runtime/scene-runtime.ts`（新增 `boundsOf`）, `packages/editor/src/viewport/drag.ts`（增）, `packages/editor/src/viewport/drop-controller.ts`（增）, `packages/editor/src/viewport/Viewport.tsx`, `packages/editor/src/panels/LibraryPanel.tsx`, `packages/editor/test/drag.test.ts`（增）, `e2e/tests/placement.spec.ts`（增）
  （**超出预划范围的四处**，都是接上手势之后才暴露、且都在同一条路径上：
  `packages/core/src/runtime/apply-patch.ts` 两处全量重建、`packages/editor/src/lib/library.ts`
  的材质策略、`packages/editor/src/store/document-store.ts` 的选区剪枝）
- **为什么存在** M10 收尾审查抓到三条「卡面写了、代码没接」：库模型的拖放 MIME 全仓无人接收；
  T-142 明写的幽灵预览一个字都没有（`resolveDropPoint` 的 `exclude` 与 `offsetToRestOn` 都是
  为它写的，双双零调用者）；双击落点是世界原点而非视口中心地面。三条同源，合成一张卡修。
- **做**
  1. `SceneRuntime.boundsOf(nodeIds)` → 子树的世界包围盒（`Bounds | null`）。库模型的落点必须
     等资产建出来才量得到，`offsetToRestOn` 缺的就是这个输入。
  2. 编辑器侧拖拽会话 `drag.ts`（模块级，同 `snap.ts` 的理由）：`dragover` 期间浏览器**不给**
     `dataTransfer.getData`，只给 `types`，所以"正在拖的是什么"必须由 `dragstart` 存下来。
  3. 视口接受 `application/x-w3-library`：落点先解析（指针坐标只在此刻有效）→ 导入 → 用
     `boundsOf` 量出包围盒 → `offsetToRestOn` 定位 → **一条 commit**。
  4. 原始体的幽灵预览：`dragover` 首帧 `previewStart` + `preview` 建幽灵节点，其后每帧只改
     transform（落点解析带 `exclude: {幽灵}`，否则它每帧撞到自己往上爬一个包围盒），
     `dragleave` → `previewAbort`，`drop` → `previewCommit`。库模型不做幽灵（导入前量不出
     包围盒），这条**明确登记为差异**，不假装做了。
  5. 双击落点：视口中心射线打地平面，无交点回落原点。
- **验收** 拖库模型进视口真的多出对象且落在光标下；幽灵预览期间撤销栈深度不变、松手后恰好 +1；
  拖出视口再放手不留残留节点；双击在转过视角后仍落在画面内
- **自测** `pnpm -F @w3/editor test drag && pnpm -F @w3/core test bounds`
- **实际情况**：接上手势之后，四个只有在真浏览器里才看得见的缺陷立刻掉了出来，
  **单测全绿的时候它们全都在**：
  1. **取消一次拖拽会重建整个场景**。幽灵回滚的反向补丁形如
     `replace /nodes/3/transform/p` + `remove /nodes/3`，第一条指着一个已经不存在的下标，
     被当成"不认识的补丁"→ 全量重建。D1 的警报在「改主意了」这种日常动作上响，等于没有警报。
  2. **撤销第一次放置也会重建整个场景**。第一个原始体会顺手造出 默认材质 记录，撤销时连它一起
     删；而"删材质"是 apply-patch 里少数几条**故意**回落全量重建的路径。改成把受影响的节点还原成
     自带材质——本来全量重建也就是干这个。顺手补了下标位移的判断：不判断的话，删掉 A 材质会把
     用 B 材质的节点也剥光。
  3. **库模型的落点量不出来**。资产补丁是**异步**应用的（字节要先解析），紧接着 `boundsOf` 量到的
     是还没长出节点的场景图 → 永远 null → 模型永远不会被抬到落点表面上。
     单测因为 stub 了 `boundsOf` 完全看不见——正是 M10 说的那种盲区。补了 `patchesSettled()`。
  4. **撤销之后 gizmo 还挂在已经不存在的对象上**，three 每帧报一次
     `The attached 3D object must be a part of the scene graph`（E2E 里一次跑几十条）。
     修法是把"选区只能指活节点"变成 store 的不变量，按节点数守卫，拖 gizmo 那条每帧路径只多一次整数比较。
  E2E 里那条 `全量重建 = 0` 的断言是唯一能同时看见 1 和 2 的东西：对象数、撤销栈深度全都是对的。

### [x] T-145 · 内置库 manifest 机制与 starter 内容
- **依赖** T-120 · **预估** 0.8d · **实际** 0.7h
- **独占** `packages/editor/public/library/**`, `scripts/gen-library-starter.mjs`, `scripts/check-library-manifest.mjs`, `docs/LICENSES_LIBRARY.md`
- **做** manifest schema（id / 名称 / 类别 model|texture|hdri / 文件相对路径 / 预览图 / **license 必填**）+ 加载校验；`check-library-manifest.mjs`：零外链 + license 必填，静态扫描；starter 内容**程序化生成**（D17）：纹理若干（棋盘 / 噪声 / 拉丝金属色+法线，canvas 生成）、HDRI 2 张（渐变天空，RGBE 编码写出）、组合模型 2 个（gltf-transform 由原始体拼装）；真实美术内容包为人工供给（H2），本卡只交付机制与 starter。
- **验收** `node scripts/check-library-manifest.mjs` 绿；starter 总量 ≤ 40MB；断网可用；许可登记逐项可查（自产标 CC0）
- **自测** `node scripts/gen-library-starter.mjs && node scripts/check-library-manifest.mjs`
- **实际情况**：根目录脚本**取不到** workspace 的 `@gltf-transform/core`（它属于两个包，不属于
  根），所以 PNG / Radiance `.hdr` / glTF 二进制三个编码器全部手写（PNG 走 `node:zlib`，
  另两个直接写字节）。为一个 4 KB 的立方体给根加一个依赖是错的取舍。噪声用整数哈希不用
  `Math.random`——生成物必须逐字节可复现，否则每次跑脚本都是一次无意义的 diff。
  生成物经**真实解析器**验证：两张 `.hdr` 过 `HDRLoader`，两个 `.glb` 过 `GLTFLoader` 并解出
  带中文名的层级。starter 共 8 项 / 1.1 MB（预算 40 MB）。校验脚本做了六次变异检验：外链、
  缺 license、文件不存在、绝对路径、id 重复、类别越界，六种坏 manifest 全部被拦。
  纳入 `pnpm check:constitution` 是 T-173 的事，本卡不动 check-constitution.mjs。

---

## E15 · 材质与纹理

### [x] T-150 · 纹理与 HDRI 导入管线
- **依赖** T-120 · **预估** 0.8d · **实际** 0.9h
- **独占** `packages/editor/src/lib/import-flow.ts`（图像段）, `packages/core/src/assets/audit.ts`（图像增量）, `packages/core/src/assets/policy.ts`（增量）, 对应测试
- **做** 图片导入（png / jpg / webp → `type: 'texture'`；ktx2 透传）；`.hdr` 导入（→ `type: 'hdri'`）；体检增量：分辨率上限、非 2 幂 warn、bytes 阈值（阈值进 `policy.ts`，数值将回填附件A）；缩略图 = 缩放原图。
- **验收** 超标项 advice 具体（"4096 降 2048"而非"请优化"）；同图二次导入命中 hash 不重复存储
- **自测** `pnpm -F @w3/core test audit && pnpm -F @w3/editor test import-flow`
- **实际情况**：尺寸从**文件头**读，不解码。三个理由都成立：纯 Node 可测（C8）、发生在解码
  **之前**（R01 的前提就是"报告一个大到不该加载的资产"，解码它来得知它太大等于自相矛盾）、
  以及 `.hdr` / `.ktx2` 浏览器根本解不了。顺带写了 png/jpeg/webp(三种编码)/ktx2/hdr 五种头。
  METRICS 加了 `scopes`：一张 PNG 拿 `maxTriangles` 评级会报「三角面数 0 / 300,000 通过」，
  不算错，但正是教人不再读体检报告的那种噪声。NPOT 检查不是阈值判定，所以 MetricSpec 加了
  可选的 `level` —— 硬塞进比较会让存下来的 `limit` 变成一句假话。
  图片**自己就是自己的缩略图**（`<img>` 直接能显示），`.hdr` 没有缩略图（任何浏览器都显示
  不了未色调映射的 HDR，给个坏图不如给个类型图标）。
  **本卡新建了测试文件 `core/test/assets/audit-image.test.ts`**——卡片的自测命令
  `test audit` 原来一条测试都匹配不到（审计测试住在 pipeline.test.ts 里）。
  另动了两个 独占 外的文件：`pipeline.test.ts` 的 describePolicy 断言（7 行 → 按 scope 取），
  和 `AssetPanel.tsx` 的 accept / 分派（不改它的话新路径无法从 UI 到达，等于交付了一段
  死代码）。三次变异检验：JPEG 帧头假设固定偏移、NPOT 变成 fail、grade 忽略 scope。

### [x] T-151 · 贴图槽位应用与纹理缓存（core）
- **依赖** T-130, T-150 · **预估** 0.8d · **实际** 1.1h
- **独占** `packages/core/src/runtime/material-registry.ts`, `packages/core/src/runtime/texture-cache.ts`, `packages/core/test/runtime/material-registry.test.ts`
- **做** 六个贴图槽位接通：`AssetResolver` 取字节 → Texture（按 assetId 缓存 + 引用计数 dispose）；**色彩空间按槽位固定处理**（D3 的表不变：map/emissiveMap 走 sRGB，normal/roughness/metalness/ao 保持线性）；`uv` 块（repeat / offset / rotationDeg）应用到全部已挂槽位；aoMap 的 UV 通道按 three 0.185 行为处理并加回归断言；一切仍走 clone-on-write。
- **验收** 共享同源材质的两个 mesh，其一挂图另一不变（铁律 9 回归）；uv 更新增量生效不重建材质实例
- **自测** `pnpm -F @w3/core test material-registry`（30）+ `pnpm -F @w3/core test texture-cache`（11）
- **实际情况**：`setTextureSource` 在这张卡之前**全仓没有一个调用者**——六个槽位的代码在，
  喂给它的东西没有，又一处"两半都在、中间没接线"。
  解码函数是注入的：`createImageBitmap` 要浏览器，而缓存里真正会出错的部分（键、并发去重、
  引用计数、释放）跑在纯 Node（C8）。
  **取消贴图必须真的取消**：原来的 `if (assetId === undefined) continue` 会把上一张图留在材质上，
  面板里删掉法线贴图看不出任何变化，用户会再删一次。
  uv 每次 apply 都重写一遍，因为 three 把 repeat/offset/rotation 存在 **Texture** 上而缓存让
  Texture 跨材质共享——两个材质用同一张图不同平铺时后写的赢。这是"一资产一 Texture"的已知代价，
  登记在代码注释里，换来的是不炸显存。
  aoMap 那条变异第一次**存活**：three 0.185 的 `Texture.channel` 默认就是 0，所以我那条断言测的是
  three 不是我的代码（注释里"three 默认读第二套 uv"也是错的，已改）。改成"贴图带着 channel=1 进来
  也要被拉回 0"才转红。

### [x] T-153 · physical 参数与 base 升级（core）
- **依赖** T-151 · **预估** 0.5d · **实际** 0.6h
- **独占** `packages/core/src/runtime/material-registry.ts`（physical 段）, `packages/core/test/runtime/material-registry.test.ts`（增）
- **做** `MeshPhysicalMaterial` 参数应用（transmission / ior / thickness / clearcoat / clearcoatRoughness）；`base` 在 standard ↔ physical 间切换时重建材质实例并迁移共有参数；`transmission > 0` 时的透明处理规则固化并写测试。
- **验收** 玻璃参数组合渲染路径无 NaN / console 警告；base 切换往返参数不丢
- **自测** `pnpm -F @w3/core test material-registry`（42）
- **实际情况**：换类**不能用 three 的 `copy()`**——`MeshPhysicalMaterial.copy(标准材质)` 会去读
  源材质上根本不存在的 `clearcoat` / `ior`，结果是一堆 `undefined` 和 `NaN`，而报错出现在着色器
  编译时、离原因十万八千里。卡片验收那句「无 NaN」说的就是这个，所以迁移字段是**逐条列出来的**
  （变异 J7 把它换回 `copy()`，四条测试同时转红）。
  physical 参数只写进真的 physical 材质：JS 会欣然接受 `standard.transmission = 0.9`，属性挂上去、
  渲染器永远不读——面板上就会出现一个什么都不做的玻璃滑块，比不显示更糟。I15 负责告诉用户为什么。
  `transmission > 0` 强制 `transparent`：three 的透射走单独的渲染目标，不透明材质根本进不去，
  玻璃会渲染成一坨实心的。**文档不改写**，运行时决定怎么画文档说的东西（同 D3 的色彩空间）。
  两条变异存活并因此补/改了东西：J5「迁移字段全删」全绿，因为每条测试都在 def 里写死了 roughness，
  而迁移只对 def **没写**的字段（§6.1 的"继承源材质"）可见——补了一条从源材质 0.8 继承过来的；
  J6「去掉『只替换自己拥有的克隆』守卫」也全绿，因为那个分支在 `materialFor` 的契约下**根本不可达**，
  于是把它从运行时 `if` 改成参数类型（`rebaseIfNeeded` 收 `OwnedClone`），不可达的防御代码也是一种谎。

### [x] T-152 · 材质面板 v2（贴图 / UV / physical）
- **依赖** T-151, T-153 · **预估** 0.8d · **实际** 1.0h
- **独占** `packages/editor/src/panels/MaterialPanel.tsx`, `packages/editor/src/widgets/TexturePicker.tsx`
  （+ `packages/editor/src/lib/material-edit.ts`（增）与 `packages/editor/test/material-edit.test.ts`（增）：
  面板的判断逻辑抽出去才测得到，理由同 M10；+ `e2e/tests/material.spec.ts`（增）：手势级断言；+ styles.css）
- **做** 六槽位 UI + `TexturePicker`（项目资产页 + 内置纹理库页，选库图即触发引入流程）+ 清除槽位；uv 三控件（走 preview / previewCommit 支持拖拽调节）；`base === 'physical'` 时展开 physical 参数区。改动一律走 commit。
- **验收** 黄金路径 II 第 5 步可完成；共享材质陷阱目视复验
- **自测** `pnpm -F @w3/editor test material-edit`（13）+ `pnpm -F @w3/e2e exec playwright test material`（4）
- **实际情况**：清空槽位是 `delete` 而不是写 `undefined`——`maps` 是 strict object，显式 undefined
  过一遍 JSON 会变成"有键没值"，重新打开时校验不过：**存得好好的，就是打不开**，是这里最糟的一种坏法。
  `uv` 是 optional，所以写它必须从单位值把整块**物化**出来；直接 `params.uv.repeat = …` 会在用户
  第一次碰平铺控件时抛异常。
  离开 physical 时**丢弃** physical 参数：留着的话文档会一直挂着 I15 警告，描述一个用户在面板上
  看不见（字段已隐藏）、也没要求过的状态。要拿回来靠撤销。
  「这份材质被 N 个对象共用」的提示是补给铁律 9 的**另一半**：运行时的写时复制让"改一个螺栓整台泵
  都变了"不会发生，但只有这行字能让用户在拖滑块**之前**知道自己在哪种情形里。

### [x] T-154 · 材质预设库
- **依赖** T-152 · **预估** 0.8d · **实际** 0.7h
- **独占** `packages/editor/src/lib/material-presets.ts`, `packages/editor/src/panels/MaterialPanel.tsx`（预设区）, `packages/editor/test/material-presets.test.ts`
- **做** 预设数据 ≥ 10 种（拉丝金属 / 抛光金属 / 哑光塑料 / 亮面塑料 / 橡胶 / 玻璃 / 磨砂玻璃 / 木 / 陶瓷 / 亚克力），每种 = 一组全量 params；应用 = 全量参数 commit + 记录 preset 名（D16 填充器语义）；应用前共享检测：材质被 >1 节点引用时提示「分离后应用 / 应用到全部」二选一；「分离材质」按钮（clone 记录，commit）。
- **验收** 应用预设后删除整个库目录，发布包照常渲染（D16 的验证）；分离后原节点独立可改
- **自测** `pnpm -F @w3/editor test material-presets`（13）+ `playwright test material`（5）
- **实际情况**：D16 的验收「删掉整个库目录还能渲染」写成测试就是：**没有任何东西会拿 `preset` 去
  反查参数**。`preset` 只是个名字，参数是**拷贝**进文档的——预设表以后怎么改，都碰不到已经存好的文档。
  应用预设**保留贴图槽位与 uv**：预设描述的是表面对光的反应，不是表面上印着什么；给木纹贴了图再点
  「木」的人要的是粗糙度，不是一个空槽。
  应用是**整体替换**而不是合并：玻璃 → 拉丝金属如果留下 `transmission: 1`，金属会透明，
  而面板上没有任何东西解释这件事（变异 L1）。
  共享检测走「先问再做」：运行时的写时复制救不了这一条——**文档里只有一份记录**，而另外那些对象
  可能在镜头背后。分离后应用是**一条 commit**：用户要的不是"分离"，是"这个东西变成玻璃"。

### [x] T-155 · 资源库纹理 / 环境页签
- **依赖** T-141, T-145, T-150, T-133 · **预估** 0.5d · **实际** 0.5h
- **独占** `packages/editor/src/panels/LibraryPanel.tsx`（纹理 / 环境页签区）
  （+ `packages/editor/src/lib/environment-edit.ts` 与 `test/environment-edit.test.ts`（增）：
  「一条 commit」这条契约得在 JSX 之外才测得到；+ `e2e/tests/material.spec.ts` 第 ⑥⑦ 条）
- **做** 纹理页签：starter 纹理陈列，点选 → 引入为资产，若当前选中节点有材质则提供"挂到 map 槽位"快捷流；环境页签：HDRI 陈列，点选 → 引入 + 设 `meta.environment.hdriAssetId` + `background.type = 'hdri'`，**一条 commit**。
- **验收** 黄金路径 II 第 7 步可完成；撤销一步环境整体还原
- **自测** `pnpm -F @w3/editor test environment-edit`（7）+ `playwright test material`（7）
- **实际情况**：环境这件事有**三个字段一起动**（环境贴图、背景类型、以及经 D14 隐含的默认灯组是否
  让位），中间没有任何一个有用的中间态。分成两条 commit 就会出现"撤销之后场景仍被一张自己不再
  显示的天空照亮"。所以引入 + 设为环境是**同一条 commit**——`importThen` 让调用方把额外改动折进
  同一次提交里。
  「清除环境」不等于撤销：`background.type: 'hdri'` 配一个空的 hdriAssetId 是一个**没有背景**的场景，
  所以清除必须把背景类型也放回 `color`。
  纹理页签的「挂到基础色」在节点没有自己的材质时**明确说不**并提示怎么办——闷声引入一个用户看不见的
  资产，面板写着「已引入」而物体一点没变，是这里最容易做出来的坏体验。

---

## E16 · 多媒体

### [x] T-160 · 媒体导入与记录
- **依赖** T-150 · **预估** 0.8d · **实际** 0.7h
- **独占** `packages/editor/src/lib/import-flow.ts`（媒体段）, `packages/core/src/assets/policy.ts`（媒体阈值）, 对应测试
- **做** audio / video / image 导入 → asset（对应 type）+ media 记录（`name` = 原文件名；`durationS` 经 `HTMLMediaElement` 元数据读取，失败置空 + warn）；policy 增量：音频 ≤ 10MB、视频 ≤ 50MB、格式白名单（mp3/wav/ogg · mp4/webm · png/jpg/webp）。
- **验收** `durationS` 与真实时长误差 < 0.1s；超标与格式外文件的 advice 具体
- **自测** `pnpm -F @w3/editor test import-flow`（31）
- **实际情况**：格式判定用**白名单**而不是嗅探——能不能播是浏览器说了算，而在**存完字节之后**
  才发现播不了，等于给了用户一个在库里看得见、永远听不到的资产。
  `durationS` 在导入时读一次写进文档，而不是播的时候现读：D19 的整个意思就是 sequence 得知道
  自己的时长，现读意味着 `playMedia` 要等文件开始下载才知道该 await 多久。
  读时长的函数是**注入**的（要 `HTMLMediaElement`，而导入管线的测试跑在纯 Node）；读失败、读出
  0 / NaN / Infinity 一律当作**不知道**，`durationS` 整个字段省略——编一个没人量过的数字会把
  sequence 挂在上面。
  **「误差 < 0.1s」这条在 T-161 的 E2E 里用一段合成的、已知长度的 WAV 验**：本卡的注入式读取
  证明不了浏览器读得准，只能证明我的代码把浏览器说的话原样收下了。

### [x] T-161 · 媒体库面板
- **依赖** T-160 · **预估** 0.5d · **实际** 0.6h
- **独占** `packages/editor/src/panels/MediaPanel.tsx`
  （+ `packages/editor/src/lib/media-edit.ts` 与 `test/media-edit.test.ts`（增）；
  + `e2e/fixtures/wav.ts` 与 `e2e/tests/media.spec.ts`（增）：**T-160 欠的那条验收在这里还**）
- **做** 列表（类型图标 / 名称 / 时长 / 大小）、试听与预览、重命名、删除走 `refsTo` 确认（"该媒体被 1 个热点、2 条规则引用，确认删除？"）。
- **验收** 删除有引用媒体时提示准确；黄金路径 II 第 8 步可完成
- **自测** `pnpm -F @w3/editor test media-edit`（9）+ `playwright test media`（4）
- **实际情况**：**T-160 的「误差 < 0.1s」在这张卡还上了**——注入式读取只能证明我的代码把浏览器
  说的话原样收下，证明不了浏览器读得准。E2E 里喂一段**合成的 WAV**（裸 PCM：时长 = 采样数 / 采样率，
  没有编码器、没有帧填充、没有 VBR 头要猜），实测误差远小于 0.1s。
  引用计数走**文档索引 + 动作解析器**，不是手写扫描：`playMedia` 的媒体 id 藏在规则**动作参数**里，
  只扫 `hotspot.content` 会漏掉，于是面板说「被 1 个热点引用」而删除会静默弄坏一条规则。
  试听**故意不走 MediaBus**（T-163）：总线是场景的声音——规则启动的、`stopMedia('all')` 停的、
  退出预览要静音的；在列表里试听一个文件不属于场景，接进总线会导致点视口的停止按钮时试听也断，
  或者规则一触发试听就被掐掉。
  删除只删**记录**不删字节：字节是内容寻址且共享的，另一条记录可能指着同一个文件，而回收孤儿 blob
  是发布时的决定，不该由一个列表行悄悄做。

### [x] T-162 · 热点媒体内容
- **依赖** T-160 · **预估** 0.8d · **实际** 0.6h
- **独占** `packages/core/src/runtime/hotspot-layer.ts`, `packages/editor/src/panels/HotspotPanel.tsx`, `packages/core/test/runtime/hotspot.test.ts`（增）
- **做** 热点面板渲染 `content.mediaId`：image 自适应展示、video 原生 controls；字节经 `AssetResolver` → Blob URL，面板关闭 / 文档卸载时 revoke（生命周期计数管理）；编辑器 HotspotPanel 增媒体选择（`ref` 字段，refKind `'media'`）。**播放器零改动自动获得**（同一 core 渲染层，C3）。
- **验收** 编辑预览与 Player 面板渲染一致；revoke 计数归零无泄漏
- **自测** `pnpm -F @w3/core test hotspot`（24）+ `pnpm -F @w3/core test hotspot-media`（9）
- **实际情况**：`liveObjectUrls` 是**公开的**，就为了让测试断言它归零。这个泄漏是贵的那种——
  一个 object URL 会把整个文件钉在内存里直到标签页关闭，看十二个视频热点走完一台机器的人，
  手上就攥着十二个视频。
  最刁的一条是**面板在字节到达之前就被关掉**：URL 造出来的时候已经没人负责 revoke 它了，
  所以 attach 必须能看见"面板还是不是原来那个"（变异 P3 就是拆掉这个判断）。
  读文件失败**不能让面板倒掉**（文字还是值得显示的），但也**不能无声无息**——图片永远不出现、
  控制台里什么都没有，是一份没有任何信息的故障报告。这条是变异 P4 第一次存活逼出来的：
  原来的 `catch {}` 什么都不做，测试也就什么都断言不到。
  `resolveMedia` 是注入的：这个类是编辑器预览和播放器**共用**的那一个（C3），谁也不许伸手进
  对方的存储。播放器那边顺手把 resolver 提到 `createPlayerSession` 外面，两边读的是同一个。

### [x] T-163 · `playMedia` / `stopMedia` 动作与 MediaBus
- **依赖** T-135, T-160 · **预估** 1d · **实际** 1.3h
- **独占** `packages/core/src/runtime/media-bus.ts`, `packages/core/src/eca/actions/media.ts`, `packages/core/src/eca/types.ts`（增）, `packages/core/src/eca/headless.ts`（增）, `packages/core/src/runtime/scene-runtime.ts`（ctx 实现段）, `packages/core/test/eca/actions.test.ts`（增）, `packages/core/test/runtime-contract.ts`（增）, `docs/ECA_SPEC.md`（回写）
- **做** `MediaBus`（`<audio>` 元素池、volume / loop、`AbortSignal` 停播、**自动播放解锁**：首次用户手势前的播放请求 resolve + warn 不 reject 不卡 sequence——风险 V3 的防线）；`RuntimeContext` 四方法双实现 + 契约条目；两个动作五项齐全；await 语义按 D19（headless 用假时钟 + `durationS`；`loop` 立即 resolve **必测**；`durationS` 缺失立即 resolve + warn）；`stopMedia('all')` 供 `resetScene` / 退出预览调用（预览退出必须音停）。
- **验收** 覆盖率门槛 16/16 全绿；纯 Node 环境全部通过；退出预览音频停止（B13 语义扩展）
- **自测** `pnpm -F @w3/core test eca`（193）+ `pnpm -F @w3/core test media-bus`（18）
- **前置**：`engine.ts` 的矛盾先解决了才动这张卡，见 [ADR-0018](adr/0018-withCurrentEvent-改用-Proxy-委托.md)（人工裁决）。
- **实际情况**：**契约测试当场抓到一条分叉**——`SceneRuntime.resetScene` 静音了，
  `HeadlessRuntime.resetScene` 没有。这正是它存在的理由：两个实现各自都"对"，而 C3 要的是
  两边一致。
  自动播放这条（V3）是整个 MediaBus 存在的原因：浏览器在用户交互前拒绝播放，拒绝以 rejected
  promise 的形式到达。放它过去会中断整条规则链——用户看到的不是少了一个声音，而是**什么都
  没发生**。所以播放失败 resolve + warn。
  一个测试踩到了 JS 的默认参数陷阱：`mediaDoc(undefined)` 会触发 `= 2` 默认值，于是"没有时长"
  的用例其实有时长，测试挂在没人推进的时钟上超时 5 秒。改用 `null` 当哨兵。

---

## E17 · 质量收口

### [x] T-170 · 黄金路径 II E2E
- **依赖** 全部功能卡（含 T-137） · **预估** 1d · **实际** 2.2h
- **独占** `e2e/tests/golden-path-2.spec.ts`, `e2e/fixtures/gen-media-fixtures.mjs`
  （+ `e2e/playwright.config.ts`：给测试台加 `--autoplay-screening` 例外，理由见下；
  + `packages/core/src/assets/audit.ts`：修本卡抓到的 blocker；
  + `packages/editor/src/viewport/runtime-registry.ts`：`__w3DevMediaPlaying` / `__w3DevDoc` 两个只读钩子）
- **做** 进化规划 §2 的 12 步逐步覆盖；音频断言用运行时状态（`isMediaPlaying`）不断言声卡；断言 `fullRebuildCount === 0`；**黄金路径 I 的 spec 文件不改且保持全绿**；每步断言附变异检验（V6，防止重蹈 T-115 修的覆辙）。
- **验收** 连跑 5 次零 flaky；两条黄金路径同时全绿
- **自测** `pnpm test:e2e`
- **实际情况**：**第 ⑫ 步抓到一个 blocker**——`asset.stats` 是 `.strict()`，而 `grade()` 用的是
  「排掉一个已知键、其余全留」的黑名单写法，于是 T-150 / T-160 新增的六个测量键
  （`imageBytes` / `hdriBytes` / `imageSize` / `nonPowerOfTwo` / `audioBytes` / `videoBytes`）
  全部漏进了文档。后果：**凡是导入过图片、HDRI 或音频的项目都发布不出去**。
  而在此之前没有一条测试是红的——面板用 `checkIntegrity`（它不重跑 schema 校验），
  导入测试也全都只断言 `checkIntegrity`。这是仓库里**第一次真的把一份含 v0.5 资产的文档发布出去**。
  已改成显式白名单投影（黑名单只会再漏一次），并在 `import-flow.test.ts` 补了三条
  **`validate` 级别**的回归（图片 / 音频 / 模型各一），变异 U1 把黑名单换回来 → 两条转红。
  第 ⑫ 步的「断网」用**掐断所有外部源**而不是 `context.setOffline(true)`：后者连本地开发服务器
  一起掐，重载失败的原因就变成"页面自己取不到"，与产品依不依赖外网无关——那测的是测试台。
  现在断言的是「发布出去的包一个外部地址都不请求」，这才是 C6 的原话。
  `--autoplay-policy=no-user-gesture-required` 加在 playwright 配置里，同样是测试台的事：
  Chromium 在它认定用户交互过之前不放音频，而合成点击不一定算数。**产品自己对"被拒绝播放"
  的处理在 `media-bus.test.ts` 里测**（风险 V3：resolve + warn，让规则链活下去）。

### [x] T-171 · parity 扩展（灯光 / 媒体轨迹）
- **依赖** T-135, T-163, T-170 · **预估** 0.5d · **实际** 0.6h
- **独占** `test/parity/**`
- **做** 事件脚本增两条规则：`setLight`、`playMedia(await: true)`（假时钟推进）；两侧 `ExecResult` 序列含新动作步骤且逐项相等；做两次变异检验（如改坏 headless 的 `setLight` → parity 必须红）。
- **验收** parity 绿 + 变异检验记录在提交信息
- **自测** `pnpm test:parity`
- **实际情况**：输入文档在 parity 内部**扩展**而不是改 `createGoldenPathDocument()`——那是 §12 的
  冻结样例，一堆测试逐字断言它，为了一条测试去放宽它，冻结就不再是冻结。两侧拿到的仍是同一个对象。
  **假时钟要连定时器一起推**：tween 由 `tick()` 驱动、从来不需要它，而 `playMedia(await:true)` 挂在
  `ctx.wait` 上，那是 `SceneRuntime` 里一个真的 `setTimeout`——不推的话脚本跑完它还悬着，拆台把它
  中断，两侧各自报出一条没跑完的规则。
  新步骤的时刻**必须排在既有末步之后**：`replay` 的 `while (clock < atMs)` 只前进不后退，插一个更小的
  `atMs` 会让它在末尾瞬间触发（我第一版就踩了，`startedAt` 显示 7000 而脚本写的是 4200）。
  **变异检验的关键是要"单边"坏**：parity 比的是两侧，`stopMedia` 改成空操作两边一起坏，parity 照绿——
  这不是 parity 漏了，是它按定义看不见。真正有效的一次是让 `.w3p` 往返把 `media` 丢掉（只坏播放器侧）→ 立刻红。

### [x] T-172 · 老文档打开回归（编辑器侧）
- **依赖** T-134, T-120 · **预估** 0.5d · **实际** 0.3h
- **独占** `packages/editor/test/legacy-open.test.ts`
- **做** 打开 v1 fixture 工程：静默迁移到 v2 → 层级树无新增节点（D14：不注入灯）→ 保存 → 重开往返稳定 → `checkIntegrity` 零 error。
- **验收** 全链路断言通过
- **自测** `pnpm -F @w3/editor test legacy-open`（7）
- **实际情况**：D14 的那条恐惧写成了具名断言——**迁移一个字节都不许往层级树里塞**。
  「不注入」只有在「core 仍然点亮场景」时才是对的，否则它等于「打开是黑的」，
  所以另有一条断言 `needsDefaultLightRig` 对老文档仍然为真。
  往返测试特意**编辑之后再存**：只做"重新序列化一遍"证明不了迁移出来的文档能当日常提交的落点，
  而那才是它接下来每一次编辑要去的地方。
  写过一条"存储没被碰过"的测试，但它断言的是一个测试里根本没人用的对象——**没有意义的断言不如没有**，删掉了。

### [x] T-173 · 宪法与体积复核
- **依赖** T-145, T-170 · **预估** 0.5d · **实际** 0.3h
- **独占** `scripts/check-constitution.mjs`（挂新检查）, `size-limit.config.js`（如需）
- **做** `check-library-manifest.mjs` 纳入 `pnpm check:constitution`；size-limit 复核（预算不变 gzip ≤ 400 KB——HDRI / 媒体 / 库内容全部走资产管线不进 bundle，本卡验证这一点）；断网构建 + 断网 `pnpm dev` 冒烟，结果记入 IMPL_NOTES §2。
- **验收** `pnpm check:constitution` 全绿（含新项）；`pnpm size-limit` 通过并记录余量
- **自测** `pnpm check:constitution && pnpm size`
- **实际情况**：体积 **gzip 243.0 KB / 400 KB，余量 157 KB**。HDRI、媒体、库内容全部走资产管线
  不进 bundle——这正是本卡要验证的那句话，实测数字支持它。
  「断网冒烟」**换了一种更强的做法**：原计划是断网构建 + 断网 `pnpm dev`，实际做的是黄金路径 II
  第 ⑫ 步——发布出真 `.w3p` → Player 打开 → 拦截并断掉所有非本机源 → 重载 → 断言画面仍起来
  且**被拦截的请求数为 0**。「我这台机器拔网线还能跑」证明不了什么（可能只是缓存全都在），
  而「这个包一个外部地址都不请求」才是 C6 的原话。已记入 IMPL_NOTES §2。

### [x] T-174 · benchmark 灯光 / 阴影压力档
- **依赖** T-116, T-134 · **预估** 0.5d · **实际** 0.5h
- **独占** `packages/player/src/bench/**`（压力档段）
- **做** bench 页增灯光档位：0 / 1 / 4 / 8 盏动态灯 × 阴影 off / medium / high，记录 fps / drawcall；结果表一键复制 Markdown；在可用机器实测一轮记入 `docs/BENCHMARK.md`（目标机器实测仍是 H1 人工项 = G0.5-8）。
- **验收** 档位切换即时生效；BENCHMARK.md 有本机数据
- **自测** `pnpm -F @w3/player test bench-metrics`（28）+ 人工跑 bench 页
- **实际情况**：**两个「动态灯上限」分开报**——灯数与阴影是两种代价（前者平滑上升、后者阶梯式
  上升），混成一个数字会让人得出"灯很慢"然后干脆不用灯，而同一台机器上这两个数经常差好几倍，
  那个倍数正是排场景时最需要知道的。
  测量用的灯**经 core 的 `lightFactory` 造**，不是 `import 'three'`：`@w3/player` 不许直接碰 three（C2），
  而且走工厂意味着 bench 量的就是产品真正会建的那种对象。
  `SceneRuntime.setShadowsEnabled` 是本卡新增的一个小公开 API——文档仍是阴影的正常驱动方
  （`syncShadows` 从场景推导），这个开关只给 bench 用，因为那些灯是**测量用的砝码不是场景内容**（C1），
  一个都不许进文档。
  BENCHMARK.md 里**只记了体积一个数字**：帧率、承载上限、动态灯上限全部留空。
  开发机是 SwiftShader 软渲，帧率与真实 GPU 无可比性，填进去只会变成一个将来被人引用的错数字——
  「一份带错数字的合同附件，比一份留白的危险得多」这句话对这里同样成立。真机实测仍是 G0.5-8 / H1。

### [x] T-175 · 文档与指标收口
- **依赖** T-170~174 · **预估** 0.5d · **实际** 0.6h
- **独占** `docs/METRICS.md`, `docs/BENCHMARK.md`, `docs/附件A_数字资产规范_草案.md`, `README.md`, `docs/DEVELOPMENT.md`, `docs/TASK_BACKLOG_V0_5.md`（回填）
- **做** METRICS 增 v0.5 快照（新增动作数 16、E2E 总步数 24、`fullRebuildCount`、Player 体积、库内容体积、新增动作所需文件数是否仍 ≤3）；附件A 增补纹理 / HDRI / 媒体规格（数值全部来自 `policy.ts` 与 bench 实测，不拍脑袋）；DEVELOPMENT 增"如何新增一种灯 / 材质预设 / 库内容"操作节；台账回填。
- **验收** 每个数值有来源；一个没参与过的人照文档能新增一种材质预设并跑通
- **自测** 人工评审
- **实际情况**：METRICS 的 v0.5 快照里**主包只涨了 4.5 KB**（gzip 230.1 → 234.6），
  而灯光、原始体、贴图缓存、MediaBus、热点媒体全部加了进去——这个数字是 D11–D20 那批
  「复用而不是并列」决策最直接的收益证明，比任何一段说明都有力。
  趋势观察点写下了这一版最该记住的一条：**测试总数涨了 73%，但抓到 blocker 的不是它**，
  是 E2E 第一次真的走完发布。1,295 条单测全绿的同时，凡导入过图片的项目都发布不出去。
  附件A 增补的每个数值都标了 `[代码] DEFAULT_POLICY.xxx` 的出处；帧率类仍然留空
  （软渲数字不进合同附件）。
  DEVELOPMENT 增了 §4.5「新增一种材质预设 / 一种灯 / 一条库内容」，三件事都是"改一处数据、
  不碰逻辑"，并写明了三条会当场 fail 的红线（外链 / 缺 license / 超预算）。

### [x] T-176 · v0.5 全量对抗式审查
- **依赖** T-175 · **预估** 1d · **实际** 1.5h（五维并行 + 三视角证伪）
- **独占** `docs/IMPL_NOTES.md`（登记）
- **做** ≥ 4 个维度并行找问题（规范一致性 / 假绿测试 / 宪法违背 / 性能悬崖），每条发现由 3 个独立视角试图证伪；blocker 与 major 修复，其余如实登记进 IMPL_NOTES §4（v0 的先例：22 条发现存活 18 条，其中 2 条 blocker 全部有单测覆盖周边却没被发现——测试测的是函数，不是函数的用处）。
- **验收** 发现清单与修复 / 登记状态入 IMPL_NOTES；无未登记的已知问题
- **自测** 人工评审 + `pnpm verify` + `pnpm test:e2e`
- **实际情况**：**27 条发现**（规范一致性 6 / 假绿测试 5 / 宪法违背 4 / 性能悬崖 7 / 数据完整性 5），
  blocker+major 17 条。前 4 条各由三个独立视角试图证伪，**四条全部存活**（被驳 0–1 / 3）。
  **修了 6 条**（含 4 条 blocker），每条附变异检验；其余如实登记。
  四条存活的 blocker 里三条是**同一种形状**：「引用不是从它被指向的地方走过去的」——
  贴图没有节点指向它（发布包漏字节，v0.5 招牌功能在发布物里静默消失）、
  `expectType` 没有生产者（I14 形同虚设，灰区裁决建立在一道不存在的闸门上）、
  整块 `/nodes` 路径不认识 `assetRef`（二次上传后视口画旧几何，且 `fullRebuildCount` 不报警）。
  **每一条周边的测试都是全绿的。**

---

## E18 · v0.5 债务清偿（T-176 登记项）

T-176 修了 6 条、登记了其余。这一节把登记项立成卡逐条清掉，**不留"已知但没人负责"的条目**。
每张卡的验收都包含：一条能复现原问题的测试 + 一次变异检验。

### [x] T-180 · 「存得下、打不开」路径收口
- **独占** `packages/core/src/assets/instantiate.ts`, 对应测试
- **做** 导入的模型若有超过 120 字符的物体名 → 生成的节点违反 `NodeSchema` → **整份工程从此打不开**。
  规范化节点名（截断 + 保留可读尾巴），并**系统性排查**其余由外部数据流进文档的字段（资产名、objectPath、动画名）。
- **验收** 造一个超长名的 GLB，导入后 `validate` 通过；截断策略有测试
- **实际情况**：全仓只有**两个**长度受限的字符串字段（`document.name` 与 `node.name`），
  而只有后者由外部数据（GLB 的物体名）喂进来——排查结论比修复本身更有价值。
  `clampNodeName` 放在**约束旁边**（`node.ts`）而不是导入管线里：上限和尊重上限的那段代码
  分头演化，正是这个 bug 的成因。
  **保留名字的尾巴而不是开头**：导出器给的名字长这样 `Assembly_Rev3_SubAssembly_…_Bolt_M6x20`，
  能把两个零件区分开的信息全在末尾，从右边截等于把一层结构变成四十行一模一样的东西（变异 A2 抓这条）。

### [x] T-181 · 共享 Texture 的 colorSpace 与 UV 隔离
- **独占** `packages/core/src/runtime/texture-cache.ts`, `material-registry.ts`, 对应测试
- **做** 一资产一 Texture 让 `colorSpace` 与 uv 变换互相踩踏：同一张图同时挂「基础色」与「粗糙度」→ 最终线性 → 物体发白（已实测复现）；两个材质用同一张图不同平铺 → 后写的赢。
  按**用途**（colorSpace）分变体，uv 按材质分变体；变体共享解码后的 image，不重复解码。
- **验收** 上述两个场景各一条测试；变体数有上界且被断言
- **实际情况**：修的地方不是材质，是 **Texture 实例的分配策略**。`colorSpace` / `repeat` /
  `offset` / `rotation` 都长在 three 的 Texture 上而不是材质上，所以「一个资产一个 Texture」
  这条省显存的规则同时意味着「谁最后写谁说了算」。改成**一个 (资产, 采样状态) 一个实例**：
  采样状态相同的用法照旧共享，实例数由「有几种不同设置」决定，不由「有几个材质」决定，
  clone 共享已解码的图，解码次数不变。
- 顺带修了 `applyUv` 里一个 `return` 该是 `continue`：第一个槽的 wrap 已经对了就整个函数
  退出，后面的槽全部拿不到 uv。**只有平铺 ≤1× 时才够得着**（想要的 wrap 恰好是默认值），
  所以变异 B5 第一版没抓住——我把测试改成 1× + 旋转 45° 才让它红。这条比 bug 本身值得记：
  一个"显然在测这件事"的测试可以完全够不着它要测的分支。
- **变异检验**：B1 变体退回共享 → 4 红；B2 key 丢 colorSpace → 2 红；B3 key 丢 uv → 1 红；
  B4 每次都造新实例 → 1 红（无界会被抓）；B5 早退回 return → 1 红；B6 dispose 不回收副本 → 1 红。
- **实际耗时**：0.6 天


### [x] T-182 · 预览态摘掉编辑期物件（C3）
- **独占** `packages/editor/src/preview/controller.ts`, `packages/core/src/runtime/light-helpers.ts`
- **做** 预览里灯光 helper 与拾取代理球仍在：**预览里点得到灯、播放器里点不到**，且用户「发布前最后看一眼」看到的不是发布出去的画面。网格已经这么处理了，灯光 helper 没有一并适用。
- **验收** 预览期间 helper 计数为 0、代理球不参与拾取；退出预览后回来
- **实际情况**：预览不是第二个 runtime——编辑器留着自己 `mode: 'edit'` 的那个，只是把 ECA
  引擎打开。于是 `mode === 'edit'` 造出来的东西全都还在场景里：预览画着播放器永远不会画的
  地面网格和灯线框，而且点击会打中灯的拾取代理，viewer 瞄准的物体上的规则不触发。
  这正是 C3 分叉，出现在**唯一一个存在意义就是排除分叉的功能**上。
- 新增 `SceneRuntime.setEditorChromeVisible()`，编辑器在预览进出时调用。**藏而不销毁**：
  预览会被反复切换，每次重建线框层只是把热状态丢掉。
- **一个机制而不是两个**：第一版同时把 aux root 从 picker 上摘掉，变异 C1 却是绿的——
  本项目的 `isPickable` 本来就沿着祖先链查 `visible`（正因为 three 的 raycaster 不查）。
  两条路径互为冗余，于是**单独敲掉任何一条都测不出来**。删掉多余那条之后，C3 一次放倒两条测试。
  写在这里是因为它是个通用现象：冗余的保障机制会让变异检验集体失灵。
- **变异检验**：C1 只摘 picker 不藏 → **绿（据此删掉了这条冗余路径）**；C2 不藏网格 → 1 红；
  C3 不藏线框 root → 2 红；C4 退出预览不还原 → 2 红。
- **实际耗时**：0.4 天


### [x] T-183 · HDRI 端到端验证
- **独占** `packages/core/test/runtime/environment-wiring.test.ts`（增）, `e2e/tests/golden-path-2.spec.ts`
- **做** 「HDRI 照亮场景」全仓零验证：`EnvironmentController` 只在隔离桩里测过，删掉 `await this.environment.apply(doc)` 全套测试照绿。补 `SceneRuntime` 接线断言 + E2E 断言**渲染器**（`scene.environment` 非空）。
- **验收** 上述删除能让测试转红
- **实际情况**：`EnvironmentController` 本身测得很足，24 条里 18 条都是它的——**但全部直接
  驱动控制器**，于是「runtime 到底调没调它」一条都没测到。删掉 `SceneRuntime.load` 里的
  `await this.environment.apply(doc)`，全仓绿。一个完全正确、但没人调用的控制器，在播放器里
  是黑背景，在编辑器里什么都没有。
- 补的六条全部走 `SceneRuntime` 并断言 `runtime.scene`（three 真正要画的那个对象）。
  三个调用点各是一种「HDRI 不出现」的方式：打开文档、构造时就带着、改环境的 patch。
- **两次「测试写得像在测那件事，其实没测」**：
  1. 六条里三条一开始用**带 HDRI 的文档构造 runtime**，而构造函数本身就会 apply——
     贴图在测试做任何事之前就已经在场景里了，删掉被测的那行毫无变化。D1 变异抓出来的。
     改成「runtime 出生时没有 HDRI，之后才拿到」。
  2. 原来那条「画布晚到」测的是**公开 API 到不了的路径**：`attachRenderer` 是私有的，
     只在构造函数里调。改成它真实的形状：直接带画布和 HDRI 构造，没人调 `load`。
- 顺带把 `renderer` 私有字段的断言改成**持有注入的那个桩**，而不是为测试放宽生产可见性。
- **变异检验**：D1 load 不 apply → 2 红（第一版是绿的）；D2 构造时不 apply → 1 红；
  D3 patch 路径不 apply → 1 红；D4 色调映射恒为 ACES（破 G0.5-6）→ 2 红。
- **实际耗时**：0.5 天


### [x] T-184 · O(n²) 性能悬崖收口
- **独占** `packages/schema/src/index-builder.ts`, `packages/editor/src/panels/tree-dnd.ts`, `packages/editor/src/App.tsx`, `packages/core/src/runtime/{apply-patch,scene-runtime,primitive-factory}.ts`
- **做** 1000 节点实测：删除靠前节点 `applyPatch` 97 ms、`flattenTree` 8.9 ms/帧、`buildIndex` 8.5 ms/次、状态栏 `checkIntegrity` 4.7 ms/次、`syncShadows(force)` O(n²)、`primitiveBounds` 被接到每次指针移动。
  一次建好父子索引，把每节点一次全表 filter 改成一次分组。
- **验收** 1000 节点基准测试有数字且进 METRICS；**增量路径必须快于全量重建**
- **实际情况**：六处悬崖**只有一个根因**——`getChildren` 是一次全表扫描，而所有需要
  「很多个节点各自的孩子」的代码都在循环里调它。抽出 `groupChildren`（一次分组），
  `buildIndex` / `walkTree` / `getDescendants` / `flattenTree` 全部改成用它。
  另外三处：`syncShadows(force)` 逐 id 调 `syncNodeShadowFlags`（内含 `find`）→ 直接遍历节点；
  `resyncNode` 每个节点都 `find` 自己并重建一次材质 Map → 改成把节点和 Map 传进去；
  `primitiveBounds` 被 `dragover` 每次指针移动调用 → 单条记忆化（拖拽期间图元不变，命中率 100%）。
- **数字**（1000 → 4000 节点，ms）：`buildIndex` 6.78→0.25 / 100.00→0.80；
  `checkIntegrity` 4.97→0.49 / 62.12→1.94；`walkTree` 4.46→0.12 / 57.06→0.46；
  删一个节点后重建 6.77→0.10 / 106.13→0.61。全部由 O(n²) 变线性。已进 METRICS。
- **验收「增量路径必须快于全量重建」**：删一个节点的增量路径在 4000 节点上是 0.61 ms，
  全量 `buildIndex` 是 0.80 ms，且两者都已线性——原来是 106 ms vs 100 ms，
  「增量」比全量还慢，这条验收标准此前根本不成立。
- **两条变异是绿的，两条都是测试自己的毛病**（详见 METRICS 同节）：基准文档恰好已按
  `order` 排好，排序是空操作；孤儿节点用新建的顺序 id 工厂造，id 和已有根节点撞了。
  两条测试读起来都完全正确。没有变异检验，这张卡会带着两条假绿收工。
- **变异检验**：E1 childrenOf 退回每节点一次 filter → 3 红；E2 不排序 → 1 红（修测试后）；
  E3 叶子不建桶 → 2 红；E4 父级不存在的节点被丢弃 → 1 红（修测试后）。
- **实际耗时**：1.2 天


### [x] T-185 · 假绿收口
- **独占** `packages/editor/test/{patch-forwarder,undo-runtime-parity}.test.ts`, `packages/core/test/eca/actions.test.ts`
- **做** `createPatchForwarder` 零单测（改坏 `'assets'` 判断两套测试照绿）；`undo-runtime-parity` 的 snapshot 不含 v0.5 的灯光/原始体/贴图/阴影标志位；「六种字段」守卫写死了错误集合（混入不存在的 `vec3`、漏掉合法的 `valueExpr`），与 `FieldDescriptor` 无机械联系。
- **验收** 三条各有一次变异检验
- **实际情况**：三条都补了，**而且三条在写的过程中各自先假绿了一次**，全靠变异检验揪出来。
  1. `createPatchForwarder` 补 12 条。原始发现「改坏 `'assets'` 判断两套测试照绿」
     现在是 5 条红。
  2. `undo-runtime-parity` 的 snapshot 加上灯参数 / 几何参数 / 贴图槽（含采样状态）/
     阴影标志位，并给文档补进一盏聚光灯和一个立方体、给随机编辑加四种 v0.5 操作——
     **只扩 snapshot 不扩编辑，等于给每个节点断言 `null === null`**。
  3. 「六种字段」守卫改成从 `FIELD_KINDS` 常量导入，而 `FieldDescriptor['type']` 反过来
     由这个常量派生。常量和联合类型再也不可能各写各的。
- **三次「测试读起来完全正确但什么都没测」**：
  1. 脚手架用**新建的顺序 id 工厂**造灯和立方体，id 和黄金路径已有节点撞了，
     于是每次 `nodes.find(n => n.id === …)` 都找到错的节点，四种 v0.5 编辑全成空操作。
     **和 T-184 那条孤儿测试是同一个坑，同一天踩了两次。**
  2. 前置断言写的是 `not.toBeNull()`——`undefined` 也能过。正是它把上面那个 id 冲突盖住了。
     改成断言形状（`toBe('SpotLight')`）。
  3. 最本质的一条：**parity 测试只比较「编辑前」和「撤销后」，而变异让正向路径也不动了**，
     于是灯根本没变过，撤销自然"还原"得完美。补上「中途必须真的变了」的断言之后才红。
     **对称性测试不能证明正向路径发生过，两头都得断言。**
- **变异检验**：F1 改坏 `'assets'` 判断 → 5 红；F2 贴图引用不等字节 → 1 红；
  F3 判断放宽成整个 `/materials` → 1 红；F4 不串行 → 1 红；F5 先应用再等字节 → 3 红；
  F6 无条件 frameAll → 1 红；G1 灯参数不写回 → 1 红；G2 原始体不重建几何 → 1 红；
  G3 阴影 patch 不派发 → 1 红；H1 第七种字段类型 → 1 红；
  H2 `FIELD_KINDS` 自己写漏 → **测试全绿但 typecheck 报错**（这正是机械联系的意义：
  守卫写错不再是绿灯，而是编译不过）。
- **实际耗时**：0.9 天


### [x] T-186 · minor 收口
- **独占** 见各条
- **做** D19「先到者为准」实际只等 `durationS`（`waitForEnd` 零生产调用者）；规则编辑器媒体下拉显示文件名而非 `media.name`；`resetScene` 的 `describe()` 未随 v0.5 更新；executor 的 B9 对 media 直接放行；清空贴图槽位不释放显存（M11 登记）。
- **验收** 逐条测试
- **实际情况**：五条逐条落地。
  1. **D19「先到者为准」**：`MediaBus.waitForEnd` 写好了、测过了、**零个生产调用者**——
     一段完整实现从未接进任何路径。动作只等 `durationS`（导入时浏览器报的数，和实际
     播放长度能差出几百毫秒到几秒），于是「响完铃再弹面板」不是早弹就是晚弹。
     接法需要给 `RuntimeContext` 加一个方法 → **[ADR-0019](adr/0019-媒体等待以先到者为准.md)，
     并回写 ECA_SPEC §7 接口清单**（这是一次规范扩张，按铁律 12 立了 ADR）。
     headless 侧永不 resolve，于是时钟必胜——正是 D19 对 headless 的要求。
  2. 媒体下拉改用 `media.name`：此前读的是资产名（导入时的文件名），用户在媒体面板
     改成「警报声」后规则编辑器照旧显示 `alarm.wav`，同一文件切出来的两条也分不开。
  3. `resetScene` 的 `describe()` 补上 v0.5 真正会还原的东西（停播放与高亮、灯光）。
     它是 R14 验收文档的生成源，旧文案描述的是一个比实际发货范围更窄的动作。
  4. B9 的 `refExists` 有一条 v0 遗留的 `default: return true`，媒体直接放行——
     指向已删除片段的规则**报告成功且不出声**。顺带补上 `expectType` 检查（§4.2 I14）。
  5. 清空贴图槽位**已经不漏显存了**：M11 自己的修复（转发器把 `/materials/**/maps/*`
     走慢路径）顺带把清空也带进了 `ensure` → `retainOnly`。写成测试而不是改注释，
     因为这条联系是间接的、只在转发器继续按 `maps` 判断时成立。
- **两条变异是绿的，两条都指向同一个毛病**：
  - I1 取消竞速全绿——headless 侧本来就永不 resolve，**在 headless 里「竞速」和「只等时钟」
    构造上就不可区分**。补了一条走真实 `MediaBus` 的测试：`durationS` 写成一小时，
    元素立刻 `ended`，接上竞速就立即返回，没接就要等满一小时。
  - I4 B9 放行全绿——我新加的 `expectType` 检查把存在性检查**盖住了**
    （记录不存在时 `undefined?.type !== 'audio'` 也会跳过）。**两道守卫覆盖同一个保证，
    于是哪一道都单独测不出来**——和 T-182 的 C1 是同一个形状，同一批卡里第二次遇到。
    把断言收紧到报错**措辞**（「已不存在」而不是「类型不对」）才分得开。
- **变异检验**：I1 取消竞速 → 1 红（第一版绿）；I2 headless 立即 resolve → 1 红；
  I3 SceneRuntime 不接 MediaBus → 1 红；I4 B9 对 media 放行 → 1 红（第一版绿）；
  I5 B9 不查 expectType → 1 红；I6 媒体下拉退回文件名 → 1 红。
- **实际耗时**：0.8 天


---

## 收尾：v0.5 晋级门槛核对

全部任务卡完成后，逐条核对 [NORTH_STAR.md](NORTH_STAR.md) §3 的 G0.5-1 ~ G0.5-8：

核对于 2026-08-01，逐条跑过命令；**E18 债务清偿（T-180 ~ T-186）完成后于 2026-08-02 复核**，
结果如下（括号内为复核数字）。

- [x] **G0.5-1** 黄金路径 II 全绿 + 黄金路径 I 回归全绿（T-170）
      → `pnpm test:e2e` **28 passed**（路径 I 12 步 · 路径 II 12 步 · 专项 17 条），
      两条路径各自 `--repeat-each=5` 零 flaky。**复核仍 28 passed**
- [x] **G0.5-2** 宪法检查全绿，含库 manifest 零外链（T-173）
      → `pnpm check:constitution` **PASS**（含新挂的 `check-library-manifest.mjs`）
- [x] **G0.5-3** v1 + v2 fixture 迁移回归全过（T-120）
      → `pnpm -F @w3/schema test` **229 passed**；另有 T-172 的 7 条打开-编辑-往返回归。
      **复核 236 passed**（T-184 新增 7 条规模与索引一致性）
- [x] **G0.5-4** parity 含灯光 / 媒体轨迹（T-171）
      → `pnpm test:parity` **3 passed**，轨迹内含 `setLight` 与 `playMedia(await)`，
      并有断言防止脚本以后漂成空的；单边变异确认它会红。
      **复核 3 passed——而且在 T-186 途中真的红过一次**：D19 竞速接上后两侧
      *一致地*变成立即返回，两侧比较看不出来，是那条「场景是否真的跑到有意思的分支」
      自检抓到的（[ADR-0019](adr/0019-媒体等待以先到者为准.md)）。这条门槛不是摆设。
- [x] **G0.5-5** 动作覆盖 100%（16/16）（T-135 / T-163）
      → 注册 16 个，`actions.test.ts` 的覆盖门槛全绿（少一个就会点名）。
      **复核仍 16/16**；T-186 另把 B9 的媒体放行补上（此前指向已删除片段的规则报告成功）
- [x] **G0.5-6** 老文档默认观感回归（T-134 / T-172）
      → `test legacy-open` 9 passed + `test default-rig` 9 passed：
      迁移不注入任何节点，且老文档仍由内置灯架照亮
- [x] **G0.5-7** Player gzip ≤ 400 KB（T-173）
      → `pnpm size` **243.7 KB / 400 KB**，余量 39.1%。**复核未新增运行时依赖**
- [ ] **G0.5-8** 目标机器 benchmark 实测（T-174 + H1，**顺延的 G0-7**）
      → **未过，且不是代码能解决的**：本仓库开发与 CI 环境只有 SwiftShader 软件渲染。
      T-174 已把灯光 / 阴影压力档做进 bench 页并有单测，`docs/BENCHMARK.md` 只记了与显卡
      无关的体积一项，帧率类**故意留空**——软渲数字填进合同附件比留白危险得多。
      **这是一条人工供给项（H1）：拿到目标机器跑一遍 bench 页即可闭合。**

**E18 复核补充**：T-184 另立了一条与显卡无关的 CPU 规模基准
（`node scripts/bench-scale.mjs`，数字进 [METRICS.md](METRICS.md)）。
它不能替代 G0.5-8——帧率仍必须在目标机器上测——但把「1000 节点下编辑器卡不卡」
这一半从硬件供给里拆了出来，**现在有数字、有阈值、有回归测试**。

**七条机械门槛全过，第八条卡在硬件供给上。** 按 NORTH_STAR §3 的原文「任何一条不过，
不许开工 v1」——所以现在**不能开工 v1**，需要的是一台目标机器，不是更多代码。

八条全过 → v0.5 完成，可以开工 v1。**任何一条不过，不许开工 v1。**

---

**预估总计**：约 25 人日（清债 2.1 + schema 2.5 + 光照 4.4 + 对象与放置 4.1 + 材质纹理 4.2 +
多媒体 3.1 + 质量收口 4.5）。与 v0 的 42 人日相比几乎减半，原因是底座在替 v0.5 干活：
灯和原始体复用了节点的全部机制（层级 / gizmo / 撤销 / patch），三个新动作复用了注册表，
媒体复用了 v1 就预留的字段。**如果实际耗时显著超出这个数，最可能的原因是有能力没有
"长在底座上"而是另起炉灶——先查 D12 / D15 / V9，再查排期。**
